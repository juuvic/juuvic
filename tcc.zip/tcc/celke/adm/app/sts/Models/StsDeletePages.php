<?php

namespace App\sts\Models;

if(!defined('C8L6K7E')){
    header("Location: /");
    die("Erro: Página não encontrada<br>");
}

/**
 * Apagar a página no banco de dados
 *
 * @author Celke
 */
class StsDeletePages
{

    /** @var bool $result Recebe true quando executar o processo com sucesso e false quando houver erro */
    private bool $result = false;

    /** @var int|string|null $id Recebe o id do registro */
    private int|string|null $id;

    /** @var array|null $resultBd Recebe os registros do banco de dados */
    private array|null $resultBd;

    /** @var string $delDirectory Recebe o endereço para apagar o diretorio */
    private string $delDirectory;

    /** @var string $delImg Recebe o endereço para apagar a imagem */
    private string $delImg;

    /**
     * @return bool Retorna true quando executar o processo com sucesso e false quando houver erro
     */
    function getResult(): bool
    {
        return $this->result;
    }

    /**
     * Metodo recebe como parametro o ID que sera usado para excluir o registro da tabela sts_pages
     * Chama a função viewPages para verificar se a página esta cadastrada no sistema e na sequencia chama a funcao deleteImg para apagar a imagem da página
     * @param integer $id
     * @return void
     */
    public function deletePages(int $id): void
    {
        $this->id = (int) $id;

        if($this->viewPages()){
            $deletePages = new \App\adms\Models\helper\AdmsDelete();
            $deletePages->exeDelete("sts_pages", "WHERE id =:id", "id={$this->id}");
    
            if ($deletePages->getResult()) {
                $this->deleteImg();
                $_SESSION['msg'] = "<p class='alert-success'>Página apagada com sucesso!</p>";
                $this->result = true;
            } else {
                $_SESSION['msg'] = "<p class='alert-danger'>Erro: Página não apagada com sucesso!</p>";
                $this->result = false;
            }
        }else{
            $this->result = false;
        }
        
    }

    /**
     * Metodo faz a pesquisa para verificar se a página esta cadastrada no sistema, o resultado he enviado para a funcao deletePages
     *
     * @return boolean
     */
    private function viewPages(): bool
    {

        $viewPages = new \App\adms\Models\helper\AdmsRead();
        $viewPages->fullRead("SELECT id, image_page
                            FROM sts_pages                           
                            WHERE id=:id
                            LIMIT :limit", "id={$this->id}&limit=1");

        $this->resultBd = $viewPages->getResult();
        if ($this->resultBd) {
            return true;
        } else {
            $_SESSION['msg'] = "<p class='alert-danger'>Erro: Página não encontrada!</p>";
            return false;
        }
    }

    /**
     * Metodo usado para apagar a imagem e o diretorio sobre empresa no servidor
     *
     * @return void
     */
    private function deleteImg(): void
    {
        if((!empty($this->resultBd[0]['image_page'])) or ($this->resultBd[0]['image_page'] != null)){
            $this->delDirectory = "app/sts/assets/image/pages/" . $this->resultBd[0]['id'];
            $this->delImg = $this->delDirectory . "/" . $this->resultBd[0]['image_page'];

            if(file_exists($this->delImg)){
                unlink($this->delImg);
            }

            if(file_exists($this->delDirectory)){
                rmdir($this->delDirectory);
            }
        }
    }
}
