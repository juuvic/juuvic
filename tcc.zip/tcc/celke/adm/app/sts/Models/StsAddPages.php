<?php

namespace App\sts\Models;

if(!defined('C8L6K7E')){
    header("Location: /");
    die("Erro: Página não encontrada<br>");
}

/**
 * Cadastrar nova página no banco de dados
 *
 * @author Celke
 */
class StsAddPages
{
    /** @var array|null $data Recebe as informacoes do formulario */
    private array|null $data;

    /** @var bool $result Recebe true quando executar o processo com sucesso e false quando houver erro */
    private bool $result;

    /** @var array $dataExitVal Recebe as informações que serão retiradas da validação*/
    private array $dataExitVal;

    /**
     * @return bool Retorna true quando executar o processo com sucesso e false quando houver erro
     */
    function getResult(): bool
    {
        return $this->result;
    }

    /** 
     * Recebe os valores do formulario.
     * Instancia o helper "AdmsValEmptyField" para verificar se todos os campos estao preenchidos 
     * Verifica se todos os campos estao preenchidos e instancia o método "valInput" para validar os dados dos campos e retira campo "obs" da validação
     * Retorna FALSE quando algum campo esta vazio
     * 
     * @param array $data Recebe as informações do formulario
     * 
     * @return void
     */
    public function create(array $data = null)
    {
        $this->data = $data;

        $this->dataExitVal['obs'] = $this->data['obs'];
        unset($this->data['obs']);

        $valEmptyField = new \App\adms\Models\helper\AdmsValEmptyField();
        $valEmptyField->valField($this->data);
        if ($valEmptyField->getResult()) {
            $this->add();
        } else {
            $this->result = false;
        }
    }

    /** 
     * Cadastrar página no banco de dados
     * Retorna TRUE quando cadastrar a página com sucesso
     * Retorna FALSE quando nao cadastrar a página
     * 
     * @return void
     */
    private function add(): void
    {
        $this->data['obs'] = $this->dataExitVal['obs'];
        $this->data['created'] = date("Y-m-d H:i:s");

        $createPages = new \App\adms\Models\helper\AdmsCreate();
        $createPages->exeCreate("sts_pages", $this->data);

        if ($createPages->getResult()) {
            $_SESSION['msg'] = "<p class='alert-success'>Página cadastrada com sucesso!</p>";
            $this->result = true;
        } else {
            $_SESSION['msg'] = "<p class='alert-danger'>Erro: Página não cadastrada com sucesso!</p>";
            $this->result = false;
        }
    }
}
