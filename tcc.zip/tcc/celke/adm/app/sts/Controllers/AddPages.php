<?php

namespace App\sts\Controllers;

if(!defined('C8L6K7E')){
    header("Location: /");
    die("Erro: Página não encontrada<br>");
}

/**
 * Controller cadastrar página
 * @author Cesar <cesar@celke.com.br>
 */
class AddPages
{

    /** @var array|string|null $data Recebe os dados que devem ser enviados para VIEW */
    private array|string|null $data = [];

    /** @var array $dataForm Recebe os dados do formulario */
    private array|null $dataForm;

    /**
     * Método cadastrar página
     * Receber os dados do formulario.
     * Quando o usuario clicar no botão "cadastrar" do formulario cadastra uma nova página. Acessa o IF e instância a classe "StsAddPages" responsavel em cadastrar a página no banco de dados.
     * Página cadastrada com sucesso, redireciona para a pagina listar páginas.
     * Senao, instancia a classe responsavel em carregar a View e enviar os dados para View.
     * 
     * @return void
     */
    public function index(): void
    {
        $this->dataForm = filter_input_array(INPUT_POST, FILTER_DEFAULT);        

        if(!empty($this->dataForm['SendAddPages'])){
            //var_dump($this->dataForm);
            unset($this->dataForm['SendAddPages']);
            $createPages = new \App\sts\Models\StsAddPages();
            $createPages->create($this->dataForm);
            if($createPages->getResult()){
                $urlRedirect = URLADM . "list-pages/index";
                header("Location: $urlRedirect");
            }else{
                $this->data['form'] = $this->dataForm;
                $this->viewAddPages();
            }   
        }else{
            $this->viewAddPages();
        }  
    }

    /**
     * Instanciar a classe responsavel em carregar a View e enviar os dados para View.
     * 
     */
    private function viewAddPages(): void
    {
        $this->data['sidebarActive'] = "list-pages"; 
        
        $loadView = new \App\sts\core\ConfigViewSts("sts/Views/pages/addPages", $this->data);
        $loadView->loadViewSts();
    }
}
