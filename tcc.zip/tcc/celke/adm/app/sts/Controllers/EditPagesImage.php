<?php

namespace App\sts\Controllers;

if(!defined('C8L6K7E')){
    header("Location: /");
    die("Erro: Página não encontrada<br>");
}

/**
 * Controller editar imagem da página
 * @author Cesar <cesar@celke.com.br>
 */
class EditPagesImage
{

    /** @var array|string|null $data Recebe os dados que devem ser enviados para VIEW */
    private array|string|null $data = [];

    /** @var array $dataForm Recebe os dados do formulario */
    private array|null $dataForm;

    /** @var int|string|null $id Recebe o id do registro */
    private int|string|null $id;

    /**
     * Metodo editar imagem da página.
     * Receber os dados do formulario.
     * 
     * Se o parametro ID e diferente de vazio e o usuario não clicou no botao editar, instancia a MODELS para recuperar as informacoes da página no banco de dados, se encontrar instancia o metodo "viewEditPagesImage". Se nao existir redireciona para o listar página.
     * 
     * Se nao existir a página clicar no botao acessa o ELSE e instancia o metodo "editPagesImage".
     * 
     * @return void
     */
    public function index(int|string|null $id = null): void
    {
        $this->dataForm = filter_input_array(INPUT_POST, FILTER_DEFAULT);

        if ((!empty($id)) and (empty($this->dataForm['SendEditPagesImage']))) {
            $this->id = (int) $id;
            $viewPagesImage = new \App\sts\Models\StsEditPagesImage();
            $viewPagesImage->viewPagesImage($this->id);
            if ($viewPagesImage->getResult()) {
                $this->data['form'] = $viewPagesImage->getResultBd();
                $this->viewEditPagesImage();
            } else {
                $urlRedirect = URLADM . "list-pages/index";
                header("Location: $urlRedirect");
            }
        } else {
            $this->editPagesImage();
        }
    }

    /**
     * Instanciar a classe responsavel em carregar a View e enviar os dados para View.
     * 
     */
    private function viewEditPagesImage(): void
    {
        $this->data['sidebarActive'] = "list-pages"; 
        $loadView = new \App\sts\core\ConfigViewSts("sts/Views/pages/editPagesImage", $this->data);
        $loadView->loadViewSts();
    }

    /**
     * Editar imagem da página.
     * Se o usuario clicou no botao, instancia a MODELS responsavel em receber os dados e editar no banco de dados.
     * Verifica se editou corretamente a página no banco de dados.
     * Se o usuario nao clicou no botao redireciona para pagina listar página.
     *
     * @return void
     */
    private function editPagesImage(): void
    {
        if (!empty($this->dataForm['SendEditPagesImage'])) {
            unset($this->dataForm['SendEditPagesImage']);
            $this->dataForm['new_image'] = $_FILES['new_image'] ? $_FILES['new_image'] : null;
            $editPagesImage = new \App\sts\Models\StsEditPagesImage();
            $editPagesImage->update($this->dataForm);
            if ($editPagesImage->getResult()) {
                $urlRedirect = URLADM . "view-pages/index/" . $this->dataForm['id'];
                header("Location: $urlRedirect");
            } else {
                $this->data['form'] = $this->dataForm;
                $this->viewEditPagesImage();
            }
        } else {
            $_SESSION['msg'] = "<p class='alert-danger'>Erro: Página não encontrada!</p>";
            $urlRedirect = URLADM . "list-pages/index";
            header("Location: $urlRedirect");
        }
    }
}
