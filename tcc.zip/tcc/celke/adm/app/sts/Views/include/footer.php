<?php

if (!defined('C8L6K7E')) {
    header("Location: /");
    die("Erro: Página não encontrada<br>");
}
?>

</div>

<script src="<?php echo URLADM; ?>app/adms/assets/js/custom_adms.js"></script>
<script src="<?php echo URLADM; ?>app/sts/assets/js/custom_sts.js"></script>
</body>

</html>