<?php

if (!defined('C8L6K7E')) {
    header("Location: /");
    die("Erro: Página não encontrada<br>");
}

if (isset($this->data['form'])) {
    $valorForm = $this->data['form'];
}
?>
<!-- Inicio do conteudo do administrativo -->
<div class="wrapper">
    <div class="row">
        <div class="top-list">
            <span class="title-content">Cadastrar Página</span>
            <div class="top-list-right">
                <?php
                echo "<a href='" . URLADM . "list-pages/index' class='btn-info'>Listar</a> ";
                ?>
            </div>
        </div>

        <div class="content-adm-alert">
            <?php
            if (isset($_SESSION['msg'])) {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
            ?>
            <span id="msg"></span>
        </div>

        <div class="content-adm">
            <form method="POST" action="" id="form-add-pages" class="form-adm">
                <div class="row-input">
                    <div class="column">
                        <?php
                        $controller = "";
                        if (isset($valorForm['controller'])) {
                            $controller = $valorForm['controller'];
                        }
                        ?>
                        <label class="title-input">Classe:<span class="text-danger">*</span></label>
                        <input type="text" name="controller" id="controller" class="input-adm" placeholder="Digite o controller" value="<?php echo $controller; ?>"  required>
                    </div>
                    <div class="column">
                        <?php
                        $metodo = "";
                        if (isset($valorForm['metodo'])) {
                            $metodo = $valorForm['metodo'];
                        }
                        ?>
                        <label class="title-input">Metodo:<span class="text-danger">*</span></label>
                        <input type="text" name="metodo" id="metodo" class="input-adm" placeholder="Digite o metodo" value="<?php echo $metodo; ?>"  required>

                    </div>
                </div>

                <div class="row-input">
                    <div class="column">
                        <?php
                        $menu_controller = "";
                        if (isset($valorForm['menu_controller'])) {
                            $menu_controller = $valorForm['menu_controller'];
                        }
                        ?>
                        <label class="title-input">Classe no menu:<span class="text-danger">*</span></label>
                        <input type="text" name="menu_controller" id="menu_controller" class="input-adm" placeholder="Digite o menu controller" value="<?php echo $menu_controller; ?>"  required>

                    </div>
                    <div class="column">
                        <?php
                        $menu_metodo = "";
                        if (isset($valorForm['menu_metodo'])) {
                            $menu_metodo = $valorForm['menu_metodo'];
                        }
                        ?>
                        <label class="title-input">Metodo no menu:<span class="text-danger">*</span></label>
                        <input type="text" name="menu_metodo" id="menu_metodo" class="input-adm" placeholder="Digite o metodo no menu" value="<?php echo $menu_metodo; ?>"  required>
                    </div>
                </div>

                <div class="row-input">
                    <div class="column">
                        <?php
                        $name_page = "";
                        if (isset($valorForm['name_page'])) {
                            $name_page = $valorForm['name_page'];
                        }
                        ?>
                        <label class="title-input">Nome da página:<span class="text-danger">*</span></label>
                        <input type="text" name="name_page" id="name_page" class="input-adm" placeholder="Digite o menu controller" value="<?php echo $name_page; ?>"  required>

                    </div>
                    <div class="column">
                        <?php
                        $title = "";
                        if (isset($valorForm['title'])) {
                            $title = $valorForm['title'];
                        }
                        ?>
                        <label class="title-input">Titulo da página:<span class="text-danger">*</span></label>
                        <input type="text" name="title" id="title" class="input-adm" placeholder="Digite o titulo da página" value="<?php echo $title; ?>"  required>
                    </div>
                </div>

                <div class="row-input">
                    <div class="column">
                        <?php
                        $obs = "";
                        if (isset($valorForm['obs'])) {
                            $obs = $valorForm['obs'];
                        }
                        ?>
                        <label class="title-input">Observação:</label>
                        <textarea name="obs" rows="5" id="obs" class="input-adm" placeholder="Digite a observação" ><?php echo $obs; ?></textarea>

                    </div>
                </div>        

                <div class="row-input">
                    <div class="column">
                        <?php
                        $keywords = "";
                        if (isset($valorForm['keywords'])) {
                            $keywords = $valorForm['keywords'];
                        }
                        ?>
                        <label class="title-input">Palavras Chaves:<span class="text-danger">*</span></label>
                        <input type="text" name="keywords" id="keywords" class="input-adm" placeholder="Digite as palavras chaves" value="<?php echo $keywords; ?>"  required>

                    </div>
                    <div class="column">
                        <?php
                        $description = "";
                        if (isset($valorForm['description'])) {
                            $description = $valorForm['description'];
                        }
                        ?>
                        <label class="title-input">Descrição:<span class="text-danger">*</span></label>
                        <input type="text" name="description" id="description" class="input-adm" placeholder="Digite a descrição" value="<?php echo $description; ?>"  required>
                    </div>
                </div>

                <p class="text-danger mb-5 fs-4">* Campo Obrigatório</p>

                <button type="submit" name="SendAddPages"  class="btn-success" value="Cadastrar">Cadastrar</button>

            </form>
        </div>
    </div>
</div>
<!-- Fim do conteudo do administrativo -->