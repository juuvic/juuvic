<?php
if(!defined('C8L6K7E')){
    header("Location: /");
    die("Erro: Página não encontrada<br>");
}
?>
<!-- Inicio do conteudo do administrativo -->
<div class="wrapper">
    <div class="row">
        <div class="top-list">
            <span class="title-content">Detalhes da Situação</span>
            <div class="top-list-right">
                <?php
                echo "<a href='" . URLADM . "list-pages/index' class='btn-info'>Listar</a> ";
                if (!empty($this->data['viewPages'])) {
                    echo "<a href='" . URLADM . "edit-pages/index/" . $this->data['viewPages'][0]['id'] . "' class='btn-warning'>Editar Página</a> ";
                    echo "<a href='" . URLADM . "edit-pages-seo/index/" . $this->data['viewPages'][0]['id'] . "' class='btn-warning'>Editar SEO</a> ";
                    echo "<a href='" . URLADM . "edit-pages-image/index/" . $this->data['viewPages'][0]['id'] . "' class='btn-warning'>Editar Imagem</a> ";
                    echo "<a href='" . URLADM . "delete-pages/index/" . $this->data['viewPages'][0]['id'] . "' onclick='return confirm(\"Tem certeza que deseja excluir este registro?\")' class='btn-danger'>Apagar</a> ";
                }
                ?>
            </div>
        </div>

        <div class="content-adm-alert">
            <?php
            if (isset($_SESSION['msg'])) {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
            ?>
        </div>

        <div class="content-adm">
            <?php
            if (!empty($this->data['viewPages'])) {
                extract($this->data['viewPages'][0]);
            ?>                
                <div class="view-det-adm">
                    <span class="view-adm-title">Imagem: </span>
                    <span class="view-adm-info">
                        <?php
                        if ((!empty($image_page)) and (file_exists("app/sts/assets/image/pages//$id/$image_page"))) {
                            echo "<img src='" . URLADM . "app/sts/assets/image/pages/$id/$image_page' width='250'><br><br>";
                        } else {
                            echo "<img src='" . URLADM . "app/sts/assets/image/pages/icon_home_top.jpg' width='250'><br><br>";
                        }
                        ?>
                    </span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">ID: </span>
                    <span class="view-adm-info"><?php echo $id; ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Controller: </span>
                    <span class="view-adm-info"><?php echo $metodo; ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Menu Controller: </span>
                    <span class="view-adm-info"><?php echo $menu_controller; ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Menu Metodo: </span>
                    <span class="view-adm-info"><?php echo $menu_metodo; ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Nome da Página: </span>
                    <span class="view-adm-info"><?php echo $name_page; ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Metodo: </span>
                    <span class="view-adm-info"><?php echo $controller; ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Titulo: </span>
                    <span class="view-adm-info"><?php echo $title; ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Observação: </span>
                    <span class="view-adm-info"><?php echo $obs; ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Palavras Chaves: </span>
                    <span class="view-adm-info"><?php echo $keywords; ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Descrição: </span>
                    <span class="view-adm-info"><?php echo $description; ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Cadastrado: </span>
                    <span class="view-adm-info"><?php echo date('d/m/Y H:i:s', strtotime($created)); ?></span>
                </div>

                <div class="view-det-adm">
                    <span class="view-adm-title">Editado: </span>
                    <span class="view-adm-info">
                        <?php
                        if (!empty($modified)) {
                            echo date('d/m/Y H:i:s', strtotime($modified));
                        } ?>
                    </span>
                </div>
            <?php
            }
            ?>
        </div>
    </div>
</div>
<!-- Fim do conteudo do administrativo -->