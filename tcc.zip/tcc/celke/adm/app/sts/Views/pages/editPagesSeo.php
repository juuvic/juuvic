<?php

if (!defined('C8L6K7E')) {
    header("Location: /");
    die("Erro: Página não encontrada<br>");
}

if (isset($this->data['form'])) {
    $valorForm = $this->data['form'];
}

if (isset($this->data['form'][0])) {
    $valorForm = $this->data['form'][0];
}
?>
<!-- Inicio do conteudo do administrativo -->
<div class="wrapper">
    <div class="row">
        <div class="top-list">
            <span class="title-content">Editar Seo da Página</span>
            <div class="top-list-right">
                <?php
                echo "<a href='" . URLADM . "list-pages/index' class='btn-info'>Listar</a> ";
                if (isset($valorForm['id'])) {
                    echo "<a href='" . URLADM . "view-pages/index/" . $valorForm['id'] . "' class='btn-primary'>Visualizar</a><br><br>";
                }
                ?>
            </div>
        </div>

        <div class="content-adm-alert">
            <?php
            if (isset($_SESSION['msg'])) {
                echo $_SESSION['msg'];
                unset($_SESSION['msg']);
            }
            ?>
            <span id="msg"></span>
        </div>

        <div class="content-adm">
            <form method="POST" action="" id="form-edit-pages-seo" class="form-adm">
                <?php
                $id = "";
                if (isset($valorForm['id'])) {
                    $id = $valorForm['id'];
                }
                ?>
                <input type="hidden" name="id" id="id" value="<?php echo $id; ?>">

                <div class="row-input">
                    <div class="column">
                        <?php
                        $title = "";
                        if (isset($valorForm['title'])) {
                            $title = $valorForm['title'];
                        }
                        ?>
                        <label class="title-input">Titulo:<span class="text-danger">*</span></label>
                        <input type="text" name="title" id="title" class="input-adm" placeholder="Digite o titulo" value="<?php echo $title; ?>"  required>
                    </div>
                </div>

                <div class="row-input">
                    <div class="column">
                        <?php
                        $obs = "";
                        if (isset($valorForm['obs'])) {
                            $obs = $valorForm['obs'];
                        }
                        ?>
                        <label class="title-input">Observação:</label>
                        <textarea name="obs" rows="5" id="obs" class="input-adm" placeholder="Digite a observação" ><?php echo $obs; ?></textarea>

                    </div>
                </div>

                <div class="row-input">
                    <div class="column">
                        <?php
                        $keywords = "";
                        if (isset($valorForm['keywords'])) {
                            $keywords = $valorForm['keywords'];
                        }
                        ?>
                        <label class="title-input">Palavras Chaves:<span class="text-danger">*</span></label>
                        <input type="text" name="keywords" id="keywords" class="input-adm" placeholder="Digite as palavras chaves" value="<?php echo $keywords; ?>"  required>
                    </div>
                </div>

                <div class="row-input">
                    <div class="column">
                        <?php
                        $description = "";
                        if (isset($valorForm['description'])) {
                            $description = $valorForm['description'];
                        }
                        ?>
                        <label class="title-input">Descrição:<span class="text-danger">*</span></label>
                        <input type="text" name="description" id="description" class="input-adm" placeholder="Digite a descrição" value="<?php echo $description; ?>"  required>
                    </div>
                </div>

                <p class="text-danger mb-5 fs-4">* Campo Obrigatório</p>

                <button type="submit" name="SendEditPagesSeo" class="btn-warning" value="Salvar">Salvar</button>

            </form>
        </div>
    </div>
</div>
<!-- Fim do conteudo do administrativo -->