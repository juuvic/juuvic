<?php

// Redirecionar ou para o processamento quando o usuário não acessa o arquivo index.php
if (!defined('C7E3L8K9E5')) {
    header("Location: /");
    die("Erro: Página não encontrada!");
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <!-- Aceitar caracteres especiais -->
    <meta charset="UTF-8">
    <!-- identificar o tamanho da tela do dispositivo do usuario -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- incluir o icone -->
    <link rel="shortcut icon" href="<?php echo URL; ?>app/sts/assets/images/icon/favicon.ico">

    <?php
    // Acessa o IF quando encontrou algum registro no banco de dados
    if (!empty($this->data['seo'][0])) {
        //Ler o registro do seo retornado do banco de dados
        //A função extract é utilizado para extrair o array e imprimir através do nome da chave
        extract($this->data['seo'][0]);

        // Colocar o titulo na aba do navegador
        echo "<title>$title</title>";
        echo "<meta name='description' content='$description'>";
        echo "<link rel='canonical' href='" . URL . $menu_controller . "'>";
        echo "<meta name='keywords' content='$keywords'>";
        echo "<meta property='og:image' content='" . URLADM . "app/sts/assets/image/pages/$id/$image_page'>";
    }
    ?>

    <!-- incluir o CSS -->
    <link rel="stylesheet" href="<?php echo URL; ?>app/sts/assets/css/custom.css">
    <!-- incluir a biblioteca de icone -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>