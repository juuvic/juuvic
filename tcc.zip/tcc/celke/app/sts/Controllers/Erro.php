<?php

namespace Sts\Controllers;

// Redirecionar ou para o processamento quando o usuário não acessa o arquivo index.php
if (!defined('C7E3L8K9E5')) {
    header("Location: /");
    die("Erro: Página não encontrada!");
}

/**
 * Controller da página Erro
 *
 * @author Cesar <cesar@celke.com.br>
 */
class Erro
{
    
    /** @var array|string|null $dados Recebe os dados que devem ser enviados para VIEW */
    private array|string|null $data;

    /**
     * Instantiar a classe responsável em carregar a View
     * 
     * @return void
     */
    public function index()
    {

        $listSeo = new \Sts\Models\StsSeo();
        $this->data['seo'] = $listSeo->index(); 
        
        $this->data = null;
        $loadView= new \Core\ConfigView("sts/Views/erro/erro", $this->data);
        $loadView->loadView();
    }
}